# QTIEN // PROFILE

Bản cập nhật: khoá ảnh đại diện (không cho khách tự đổi), thêm khu **SCRIPT** để show script từng làm (lướt ngang + nút copy), và cập nhật thông tin liên hệ.

## 📁 Cấu trúc file

```
qtien-site/
├── index.html
├── style.css
├── script.js         → CONFIG sửa nội dung ở đây (kể cả nội dung script)
├── README.md
└── assets/
    ├── music.mp3       → nhạc nền (bạn tự thêm)
    └── avatar.jpg       → ảnh đại diện CỐ ĐỊNH (bạn tự thêm — người xem không đổi được nữa)
```

---

## 🚀 Cách đưa lên GitHub Pages

1. Vào repo trên GitHub → **Add file → Upload files**
2. Kéo thả `index.html`, `style.css`, `script.js`, và cả thư mục `assets/`
3. Commit changes
4. Vào **Settings → Pages** → Source chọn branch `main`, root → Save
5. Vì file chính giờ tên là `index.html` (không phải `index.html`), link sẽ là:
   `https://<tên-user>.github.io/<tên-repo>/index.html`

   👉 Muốn dùng link gốc không có `/index.html` ở cuối, đổi tên file `index.html` thành `index.html` khi upload (giữ nguyên `style.css`, `script.js` bên trong nó vẫn được, không bắt buộc đổi tên các file còn lại).

---

## 🖼️ Ảnh đại diện — giờ đã khoá

Không còn nút đổi ảnh trên trang nữa. Chỉ 1 cách duy nhất để đổi ảnh: đặt file ảnh của bạn vào `assets/avatar.jpg` (đúng tên này) rồi upload đè lên GitHub. Người xem trang không có cách nào tự đổi ảnh của bạn được nữa.

---

## 📜 Khu SCRIPT — cách thêm script mới

Nội dung script được dán **thẳng vào `script.js`** (không cần file `.txt` riêng nữa) — nên mở kiểu gì cũng hiện đủ, kể cả double-click mở file trực tiếp trên máy, không cần deploy lên GitHub Pages mới xem được.

Mở `script.js`, tìm mảng `scripts` trong `CONFIG`:

```js
scripts: [
  {
    title: "Roblox Speed Script",
    content: `local player = game.Players.LocalPlayer
local char = player.Character or player.CharacterAdded:Wait()
...`
  },
  {
    title: "Tên game / tên script mới",
    content: `dán nguyên nội dung script vào đây,
xuống dòng thoải mái,
copy-paste y nguyên từ file gốc của bạn cũng được`
  }
]
```

**Các bước thêm 1 script mới:**
1. Copy 1 khối `{ title: "...", content: \`...\` }` bất kỳ trong mảng, dán xuống dưới cùng
2. Đổi `title` thành tên game/tên script
3. Xoá nội dung cũ trong cặp dấu `` ` ... ` `` (backtick), dán nội dung script thật vào giữa
4. Thêm dấu phẩy `,` ngăn cách với khối phía trên
5. Upload `script.js` lại lên GitHub

**Xoá script:** xoá nguyên khối `{ title: ..., content: ... }` tương ứng khỏi mảng.

⚠️ Lưu ý nhỏ: vì dùng dấu backtick `` ` `` để bọc nội dung, nếu script của bạn có ký tự backtick ở trong (hiếm khi xảy ra) thì cần thêm dấu `\` ngay trước nó, ví dụ `` \` ``.

---

## 📬 Đổi thông tin liên hệ

Mở `script.js`, sửa mục `contact` trong `CONFIG`:

```js
contact: [
  { label: "GMAIL",   value: "lequoctienbtm@gmail.com", href: "mailto:lequoctienbtm@gmail.com" },
  { label: "DISCORD", value: "tienzzzz_",                href: null }
]
```

- `value` là nội dung hiển thị + nội dung khi bấm nút copy
- `href` là link khi bấm vào (dùng `mailto:` cho email); để `null` nếu chỉ muốn hiển thị text (như Discord username, không có link riêng)
- Muốn thêm kênh khác (Zalo, Facebook...) chỉ cần thêm 1 dòng `{ label: "...", value: "...", href: "..." }` vào mảng

---

## ⚙️ Các tuỳ chỉnh khác

Trong `CONFIG` (đầu file `script.js`):

```js
skills: [
  { label: "CODE",      value: 10 },
  { label: "DESIGNER",  value: 5  },
  { label: "DEBUG",     value: 20 },
  { label: "Ý_TƯỞNG",   value: 65 },
  { label: "VIBE_CODE", value: 99 }
]
```
Đổi số `value` (1–100) để đổi hình dạng biểu đồ mạng nhện.

Văn bản giới thiệu, sở thích... sửa trực tiếp trong `index.html`.

---

## 🎵 Nhạc nền

Vẫn hoạt động như bản trước: bỏ file `.mp3` vào `assets/music.mp3`, nhạc tự phát ngay khi bấm nút khởi động ở màn hình boot.

---

## 🛠️ Công nghệ dùng

HTML thuần + CSS thuần + JavaScript thuần (vanilla) — không cần Node.js, không build, không cài package. Font từ Google Fonts (`JetBrains Mono`, `Space Mono`).
